package unibo.btlib.exceptions;

public class BluetoothDeviceNotFound extends Exception { }
