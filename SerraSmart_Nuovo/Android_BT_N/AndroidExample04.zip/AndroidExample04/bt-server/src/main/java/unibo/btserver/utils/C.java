package unibo.btserver.utils;

public class C {

    public static final String APP_LOG_TAG = "BT SRV";

    public class bluetooth {
        public static final int ENABLE_BT_REQUEST = 1;
        public static final String BT_SERVER_NAME = "btServer"; //MODIFY HERE
        public static final String BT_SERVER_UUID = "7ba55836-01eb-11e9-8eb2-f2801f1b9fd1";
    }
}
