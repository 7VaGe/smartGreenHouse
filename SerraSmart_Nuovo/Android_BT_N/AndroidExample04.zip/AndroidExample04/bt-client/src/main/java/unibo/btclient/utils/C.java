package unibo.btclient.utils;

public class C {

    public static final String APP_LOG_TAG = "BT CLN";

    public static class bluetooth {
        public static final int ENABLE_BT_REQUEST = 1;
        // Replace this string with that of the device acting as server
        public static final String BT_DEVICE_ACTING_AS_SERVER_NAME = "ciccio";
        public static final String BT_SERVER_UUID = "7ba55836-01eb-11e9-8eb2-f2801f1b9fd1";
    }
}
