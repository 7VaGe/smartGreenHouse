package unibo.btclientforemulator.utils;

public class C {

    public static final String APP_LOG_TAG = "BT EMULATED CLN";


}
